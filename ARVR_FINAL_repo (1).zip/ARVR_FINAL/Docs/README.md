# Docs

Place the final submission documents here:

```
MiniProject_Report.pdf
MiniProject_Presentation.pptx
```
