# Media

Place the project demonstration video and the accompanying audio in this folder.

Suggested naming:

```
MiniProject_Demo.mp4
MiniProject_Audio.m4a
```

GitHub rejects any single file larger than 100 MB. If the recording is larger than
that, compress it or upload it to Google Drive or YouTube as unlisted and put the
link here instead of the file.
